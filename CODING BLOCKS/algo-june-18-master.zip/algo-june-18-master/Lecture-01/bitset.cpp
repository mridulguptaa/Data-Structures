#include<iostream>
#include<bitset>
using namespace std;

int main(){

	bitset<100000> b;
	
	b[3] = 1;

	cout<<b<<endl;

}


