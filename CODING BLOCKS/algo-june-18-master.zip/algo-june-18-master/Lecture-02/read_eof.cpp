#include<iostream>
#include<cstdio>
using namespace std;


int main(){

	int no;
	while(scanf("%d",&no)!=EOF){
		cout<<no*no<<endl;
	}


	return 0;
}